Rails.application.routes.draw do
  mount RailsAdmin::Engine => '/mtendem', as: 'rails_admin'
  #mount RailsAdmin::Engine => '/admin', as: 'rails_admin'
  devise_for :admins
  devise_for :view4s
  devise_for :views
  resources :hires
  resources :comments
  get 'home/index'
  get 'panel/index'

  get 'info/index'
  get 'info/testimony'

  get 'infom/a'
  get 'infom/b'
  get 'infom/c'
  get 'infom/d'
  get 'infom/e'
  get 'infom/f'
  get 'infom/g'
  get 'infom/h'
  get 'infom/i'
  get 'infom/j'
  get 'infom/k'
  get 'infom/l'
 

  get 'gallery/index'

  devise_for :users
  root to: "home#index"


  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
