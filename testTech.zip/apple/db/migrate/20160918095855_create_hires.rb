class CreateHires < ActiveRecord::Migration[5.0]
  def change
    create_table :hires do |t|
      t.string :Full_name
      t.text :Job_description
      t.text :Location
      t.string :Email_address
      t.string :Phone_number
      t.string :Duration_Expected
      t.float :Minimum_amount_to_pay
      t.float :Maximum_amount_to_pay
      t.timestamp :Date

      t.timestamps
    end
  end
end
