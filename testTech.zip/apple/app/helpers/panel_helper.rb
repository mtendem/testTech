module PanelHelper
end
