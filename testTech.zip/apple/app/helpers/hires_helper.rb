module HiresHelper
end
