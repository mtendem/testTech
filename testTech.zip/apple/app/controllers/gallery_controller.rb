class GalleryController < ApplicationController
  def index
  end
end
