class InfomController < ApplicationController
end
