class PanelController < ApplicationController
  def index
  end
end
