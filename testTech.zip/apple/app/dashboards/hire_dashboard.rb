require "administrate/base_dashboard"

class HireDashboard < Administrate::BaseDashboard
  # ATTRIBUTE_TYPES
  # a hash that describes the type of each of the model's fields.
  #
  # Each different type represents an Administrate::Field object,
  # which determines how the attribute is displayed
  # on pages throughout the dashboard.
  ATTRIBUTE_TYPES = {
    id: Field::Number,
    Full_name: Field::String,
    Job_description: Field::Text,
    Location: Field::Text,
    Email_address: Field::String,
    Phone_number: Field::String,
    Duration_Expected: Field::String,
    Minimum_amount_to_pay: Field::Number.with_options(decimals: 2),
    Maximum_amount_to_pay: Field::Number.with_options(decimals: 2),
    Date: Field::DateTime,
    created_at: Field::DateTime,
    updated_at: Field::DateTime,
  }.freeze

  # COLLECTION_ATTRIBUTES
  # an array of attributes that will be displayed on the model's index page.
  #
  # By default, it's limited to four items to reduce clutter on index pages.
  # Feel free to add, remove, or rearrange items.
  COLLECTION_ATTRIBUTES = [
    :id,
    :Full_name,
    :Job_description,
    :Location,
  ].freeze

  # SHOW_PAGE_ATTRIBUTES
  # an array of attributes that will be displayed on the model's show page.
  SHOW_PAGE_ATTRIBUTES = [
    :id,
    :Full_name,
    :Job_description,
    :Location,
    :Email_address,
    :Phone_number,
    :Duration_Expected,
    :Minimum_amount_to_pay,
    :Maximum_amount_to_pay,
    :Date,
    :created_at,
    :updated_at,
  ].freeze

  # FORM_ATTRIBUTES
  # an array of attributes that will be displayed
  # on the model's form (`new` and `edit`) pages.
  FORM_ATTRIBUTES = [
    :Full_name,
    :Job_description,
    :Location,
    :Email_address,
    :Phone_number,
    :Duration_Expected,
    :Minimum_amount_to_pay,
    :Maximum_amount_to_pay,
    :Date,
  ].freeze

  # Overwrite this method to customize how hires are displayed
  # across all pages of the admin dashboard.
  #
  # def display_resource(hire)
  #   "Hire ##{hire.id}"
  # end
end
