class Comment < ApplicationRecord
	validates_presence_of :Name, :Email, :Subject, :Comment
end

