class Hire < ApplicationRecord
	validates_presence_of :Full_name, :Job_description, :Location, :Phone_number

	validates_uniqueness_of :Email_address
	validates_length_of :Email_address, :within => 5..50
	
end
