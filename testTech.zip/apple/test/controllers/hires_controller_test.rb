require 'test_helper'

class HiresControllerTest < ActionDispatch::IntegrationTest
  setup do
    @hire = hires(:one)
  end

  test "should get index" do
    get hires_url
    assert_response :success
  end

  test "should get new" do
    get new_hire_url
    assert_response :success
  end

  test "should create hire" do
    assert_difference('Hire.count') do
      post hires_url, params: { hire: { Date: @hire.Date, Duration_Expected: @hire.Duration_Expected, Email_address: @hire.Email_address, Full_name: @hire.Full_name, Job_description: @hire.Job_description, Location: @hire.Location, Maximum_amount_to_pay: @hire.Maximum_amount_to_pay, Minimum_amount_to_pay: @hire.Minimum_amount_to_pay, Phone_number: @hire.Phone_number } }
    end

    assert_redirected_to hire_url(Hire.last)
  end

  test "should show hire" do
    get hire_url(@hire)
    assert_response :success
  end

  test "should get edit" do
    get edit_hire_url(@hire)
    assert_response :success
  end

  test "should update hire" do
    patch hire_url(@hire), params: { hire: { Date: @hire.Date, Duration_Expected: @hire.Duration_Expected, Email_address: @hire.Email_address, Full_name: @hire.Full_name, Job_description: @hire.Job_description, Location: @hire.Location, Maximum_amount_to_pay: @hire.Maximum_amount_to_pay, Minimum_amount_to_pay: @hire.Minimum_amount_to_pay, Phone_number: @hire.Phone_number } }
    assert_redirected_to hire_url(@hire)
  end

  test "should destroy hire" do
    assert_difference('Hire.count', -1) do
      delete hire_url(@hire)
    end

    assert_redirected_to hires_url
  end
end
